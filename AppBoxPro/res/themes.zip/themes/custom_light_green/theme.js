﻿
$(function () {
    // Use icon font for CheckBox and RadioButton
    $('body').addClass('f-iconcheckbox');
});